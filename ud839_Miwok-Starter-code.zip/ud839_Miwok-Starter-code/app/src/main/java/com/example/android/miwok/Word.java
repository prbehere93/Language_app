package com.example.android.miwok;

/**
 * Created by DELL PC on 01-Aug-18.
 *
 * A custom class containing 2 strings a default translation of a word and a Miwok translation of that word*/


public class Word {
    private String mDefaultTranslation;
    private String mMiwokTranslation;
    private int mImageResourceID;

    //Constructor for the default class
    public Word(String defaultTranslation, String miwokTranslation, int imageResourceID ){
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mImageResourceID = imageResourceID;
    }
    //2nd constructor for just the 2 strings i.e for objects which don't contain images
    public Word(String defaultTranslation, String miwokTranslation){
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;

    }

    //Get default translation
    public String getDefaultTranslation(){
        return mDefaultTranslation;
    }

    //Get Miwok translation
    public String getMiwokTranslation(){
        return mMiwokTranslation;

    }
    //Get Image res ID
    public int getImageResourceID(){

        return mImageResourceID;
    }
}
